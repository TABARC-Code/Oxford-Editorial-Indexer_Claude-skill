# Example Editorial Control Output

## Editorial summary

The source uses three recurring concepts that should be made canonical before layout: `signal discipline`, `field register`, and `rule exception`. `Signal Discipline` appears with inconsistent capitalisation. Two cross-references point to a missing appendix. The glossary can be produced, but two entries require author confirmation.

## Glossary

| Term | Category | Definition | First occurrence | Related entries | Variants | Rejected variants | Status | Notes |
|---|---|---|---|---|---|---|---|---|
| signal discipline | Concept | The project’s system for keeping terms, references, and recurring claims internally consistent. | Section 1.2 | field register, cross-reference register | Signal Discipline | signal control | Provisional | Capitalise only when used as a formal module title. |
| field register | Editorial tool | A table used to record canonical terms, variants, status, and evidence. | Section 2.1 | glossary, style log | register | field list | Approved | Use `register` only after the full term has appeared. |

## Project index

| Main heading | Subheading | Reference | Entry type | See | See also | Note |
|---|---|---|---|---|---|---|
| cross-reference register | reverse links | Section 3.4 | Editorial tool |  | glossary, project index | Structural element. |
| Signal Discipline |  |  | Redirect | signal discipline |  | Use lowercase except in formal headings. |

## Cross-reference register

| Source | Target | Relationship type | Direction | Reason | Reader effect | Link strength | Reverse link required | Reverse link present | Status |
|---|---|---|---|---|---|---|---|---|---|
| signal discipline | cross-reference register | Dependency | Reciprocal | Signal discipline relies on managed links. | Shows how consistency is enforced. | Structural | Yes | Yes | Verified |
| field register | glossary | Dependency | Reciprocal | Glossary terms are drawn from the field register. | Helps editor trace definitions back to evidence. | Strong | Yes | No | Needs update |

## Conflict list

| Item | Problem | Evidence | Recommended action |
|---|---|---|---|
| Signal Discipline | Capitalised inconsistently. | Sections 1.2, 1.5, 4.1 | Adopt lowercase for concept, title case only for module heading. |
