---
name: writing-etiquette
parent_skill: oxford-editorial-indexer
version: 1.0.0
author: TABARC-Code
description: Editorial writing etiquette for flagging errors, delivering conflict notices, framing author decisions, and maintaining professional tone across all editorial outputs produced by the Oxford Editorial Indexer.
links:
  parent: ../../SKILL.md
  grammar_rules: ../grammar-rules/grammar-rules.md
  publishing_doctrine: ../publishing-doctrine/publishing-doctrine.md
  editorial_doctrine: ../../references/editorial-doctrine.md
  related_external_skill_1: humanizer
  related_external_skill_2: professional-technical-writing
  related_external_skill_3: forensic-style-auditor
---

# Writing Etiquette

> Sub-skill of the Oxford Editorial Indexer. Governs the tone, framing, and professional conduct of all editorial communications, conflict notices, author-decision flags, and explanatory prose this skill produces.

The editor's job is to make the work better without making the author feel ambushed. Precision without condescension. Clarity without flattery. The editorial apparatus should read like a trusted colleague, not an automated fault report.

## The fundamental tension

Editors identify problems. Authors may not want to hear about them.

The correct response to this tension is not softness — it is precision. A well-framed editorial note is harder to dismiss than a vague complaint. `The term appears in three forms across eleven sections` is more useful and harder to argue with than `the terminology feels a bit inconsistent`.

Be specific. Cite evidence. Offer the resolution, not the verdict.

## Language register

Editorial outputs should use plain, direct UK English. Not formal to the point of stiffness, but not conversational to the point of ambiguity.

### Preferred phrases

Use these when flagging issues:

| Preferred | Avoid |
|---|---|
| `Term [x] requires author confirmation.` | `This is wrong.` |
| `Two occurrences conflict.` | `You've contradicted yourself.` |
| `Recommended form: [x].` | `You should use [x].` |
| `Status: unresolved.` | `I don't know what this means.` |
| `Author decision required.` | `This is confusing.` |
| `First occurrence not confirmed.` | `I couldn't find this.` |
| `No reverse link present.` | `This link is broken.` |
| `Rejected variant: [x].` | `Don't write it like that.` |
| `Evidence absent from available source.` | `There's no proof.` |

The left column is auditable. It makes a statement that can be checked, corrected, or confirmed. The right column makes a complaint. Complaints do not improve documents.

## Flagging conflicts

When recording a conflict, give:

1. The source of conflict A and a brief quotation or reference
2. The source of conflict B and a brief quotation or reference
3. The nature of the conflict: contradictory definitions, inconsistent capitalisation, incompatible rules, or duplicate use of the same name for different entities
4. A recommended resolution — stated as a recommendation, not an instruction

Model conflict note:
```
Conflict: The term `initiative phase` appears in Section 2.3 with the definition `the period
before movement begins` and in Section 7.1 with the usage `the first player's full activation
window`. These are distinct concepts. Recommended resolution: separate into two canonical terms.
Author decision required.
```

Do not write:
```
These two sections say different things about initiative phase. You need to fix this.
```

## Framing author decisions

When an entry requires an author decision, state exactly what the decision is. Do not leave the author guessing.

```
Author decision required: confirm whether `the Archive` (used in chapters 2 and 5)
and `the Archivum` (used in chapter 8) are the same location, different locations, or
an intentional narrative shift in naming convention.
```

Not:
```
Author decision required: Archive/Archivum naming.
```

The second form looks like a note to yourself. It does not help the author. It creates a second piece of work: decoding what you meant before the actual decision can be made.

## Describing style drift

Style drift should be described neutrally. It is a document-maintenance problem, not a moral failure.

Correct: `Capitalisation of the term drifts across chapters 3, 5, and 9. Recommend adopting [preferred form] throughout.`
Incorrect: `Capitalisation is all over the place.`

## Preserving voice

When the skill encounters language that is unusual, eccentric, or genre-specific, the default is to preserve it and note it.

Do not propose smoothing out creative vocabulary unless the author has asked for a register review. An RPG rulebook that uses invented vocabulary, a fiction bible that has deliberate archaisms, a brand guide with distinctive tone — all of these are working as intended. They are not problems. They are features that need indexing, not correcting.

Note unusual terms in the glossary with `Usage note: deliberate creative term — do not normalise unless author requests.`

## Tone for different project types

### Rulebooks and game manuals
Direct and technical. No softening language. The editor is protecting the integrity of the rules, which matters more than sparing the designer's feelings.

### Fiction bibles and creative writing
Respectful and evidence-based. The author has a vision. The editor's role is to map it faithfully and flag what might confuse a reader or contradict earlier decisions. Not to rewrite.

### Academic or research documents
Formal and precise. Citation evidence is expected. Unverified claims must be flagged, not normalised.

### Brand and website content
Practical and commercial. Track consistency across products, claims, and navigation labels. Flag legal or policy language that has drifted.

## Self-audit for editorial notes

Before finalising any editorial output, ask:

1. Is every conflict note evidence-based?
2. Does every `author decision required` state exactly what needs deciding?
3. Are recommended resolutions framed as recommendations, not instructions?
4. Does the output use UK English throughout?
5. Is the tone consistent across the full output?
6. Are there any vague complaints that should be replaced with specific citations?
7. Has the author's deliberate style been preserved and noted, not flattened?

## Interaction with sub-skills

For grammar enforcement in editorial prose, see [`../grammar-rules/grammar-rules.md`](../grammar-rules/grammar-rules.md). For document structure and publishing standards, see [`../publishing-doctrine/publishing-doctrine.md`](../publishing-doctrine/publishing-doctrine.md). For deeper forensic style analysis of the source text, consider using the external `forensic-style-auditor` skill. For natural, human-sounding editorial prose, consider the external `humanizer` skill.
