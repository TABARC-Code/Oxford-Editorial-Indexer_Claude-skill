---
name: grammar-rules
parent_skill: oxford-editorial-indexer
version: 1.0.0
author: TABARC-Code
description: UK English grammar enforcement rules for glossary definitions, index entries, editorial notes, cross-reference records, and all output text produced by the Oxford Editorial Indexer.
links:
  parent: ../../SKILL.md
  publishing_doctrine: ../publishing-doctrine/publishing-doctrine.md
  writing_etiquette: ../writing-etiquette/writing-etiquette.md
  cross_reference_discipline: ../../references/cross-reference-discipline.md
  glossary_schema: ../../references/glossary-schema.md
  related_external_skill: professional-technical-writing
---

# Grammar Rules

> Sub-skill of the Oxford Editorial Indexer. Applied to all text the skill generates and all text it audits unless the project explicitly states a different house grammar standard.

This sub-skill governs sentence construction, punctuation, capitalisation, number style, list formatting, and grammatical consistency across every output this skill produces. It does not silence the author's voice. It polices the editorial apparatus — glossaries, indexes, registers, notes, summaries — not the source text.

## Jurisdiction

Apply these rules to:

- glossary definitions and usage notes
- index notes and editorial clarifications
- cross-reference reason fields and reader-effect fields
- editorial summary prose
- conflict list recommendations
- all explanatory text in output tables

Do not apply these rules directly to quoted source text. Quote exactly; flag separately.

## Sentence construction

Use complete sentences in editorial notes and summaries. Subject, verb, object. Avoid fragmented bullets where a sentence would be clearer.

Prefer active voice. Passive voice is permitted where the agent is unknown or genuinely unimportant: `the term is used inconsistently across three chapters` is correct. `three chapters use the term inconsistently` is preferred.

Avoid nominalisations where a verb is available. Write `the author confirms` not `author confirmation is required`. Write `this entry needs review` not `this entry is in need of review`.

Keep sentences tight. If a sentence requires a second reading to parse, break it. Long sentences are not prohibited, but they must earn their length through necessary complexity, not through laziness or ambiguity.

Avoid sentences that begin with `It`. Restructure: not `It is important to note that the term varies` but `The term varies`.

## Punctuation

### Oxford comma
Use the Oxford serial comma in all lists of three or more items. This is non-negotiable for a skill with `Oxford` in the name.

Correct: `glossary, index, and cross-reference register`
Incorrect: `glossary, index and cross-reference register`

### Colons and semicolons
Use a colon to introduce a list, a definition, or a direct continuation. The clause before the colon must be grammatically complete.

Correct: `The entry has three problems: undefined status, missing first occurrence, and no related entries.`
Incorrect: `The entry has: undefined status, missing first occurrence, and no related entries.`

Use a semicolon to join independent clauses that are closely related in meaning. Use sparingly. Prefer two sentences if the clauses are not tightly coupled.

### Dashes
Do not use em dashes (—) in any output this skill produces. This mirrors the parent skill's doctrine.

En dashes (–) may be used for ranges (pages 4–12, 2020–2024) if the project style permits. Otherwise use `to` in prose and hyphens in compound modifiers.

### Hyphens
Hyphenate compound modifiers before a noun: `cross-reference register`, `author-confirmed status`, `first-occurrence reference`.

Do not hyphenate after an adverb ending in -ly: `properly attributed source`, not `properly-attributed source`.

Do not hyphenate when the modifier follows the noun: `the reference is cross-referenced` not `the reference is cross-referenced` (the same in this case, but watch for ambiguity).

### Apostrophes
Use for possession and contractions only. Do not use for plurals.

Correct: `the author's decision`
Incorrect: `author decision's`

For plurals of terms, add `s` without apostrophe: `keywords`, `cross-references`, `subheadings`.

### Quotation marks
Use double quotation marks `"..."` for direct quotations from source text.
Use single backtick formatting `` `...` `` for term references in editorial tables and registers.
Use italics for titles of works only, and only when the project style supports italics in the output format.

## Capitalisation

Use sentence case for all running prose, table cell content, and editorial notes.

Use title case only for:
- formal section headings in the output document
- proper nouns and formal titles already established by the source project
- the canonical form of a term if the project has capitalised it deliberately

Do not capitalise terms merely because they feel important. Capitalisation is structural, not decorative.

When a term appears with inconsistent capitalisation in the source, record the conflict in the glossary `status` field. Do not resolve capitalisation conflicts silently.

## Number style

Spell out cardinal numbers below ten in prose: `three chapters`, `seven entries`.

Use numerals for ten and above: `12 entries`, `47 cross-references`.

Use numerals consistently in tables regardless of size.

For page and section references, use numerals: `p. 4`, `section 2.1`, `rule 17`.

Do not mix styles: `3 entries and fifteen warnings` is incorrect.

## List formatting

Use a colon before an introduced list. End each bullet with a full stop only if it is a complete sentence. Parallel grammatical structure is required: all bullets must begin with the same part of speech.

Correct:
```
The entry fails because it:
- lacks a canonical definition
- omits the first-occurrence reference
- conflicts with an existing approved entry
```

Incorrect:
```
The entry fails because it:
- No canonical definition
- The first occurrence is omitted
- Conflicts with existing entry
```

The incorrect version mixes nouns, declarative sentences, and active verbs. Choose one form. Apply it to all items.

## Register-appropriate grammar

### For glossary definitions
Short, assertive, declarative. Present tense. Define what the term *means in this project*. Not what it means in the world, not what it might mean, not what the author probably intended.

Model: `A sequence of three phases in which [x], [y], and [z] occur in strict order.`
Not: `This is basically where the game does its thing with the three phases.`

### For index entries
Fragment form is acceptable in index subheadings but not in notes. Notes must be complete sentences.

### For cross-reference reason fields
One clear sentence stating the editorial relationship. No hedging. `This term cannot be understood without reading [target].` Not `possibly related to [target] in some contexts.`

### For editorial summaries
Plain prose. Short paragraphs. No bullets unless listing specific file or section paths. Use past tense for completed actions, present tense for conditions that still exist.

## Common errors to flag in source text

When auditing source text, flag these without silently correcting:

| Error pattern | Action |
|---|---|
| `it's` used for possession | Flag: should be `its` |
| Apostrophe plurals (`index's` for `indexes`) | Flag |
| `which` vs `that` confusion | Flag where the distinction changes meaning |
| Dangling modifiers | Flag |
| Subject-verb disagreement with collective nouns | Flag with note on UK vs US convention |
| `data is` vs `data are` | Flag; note UK academic preference for `data are` |
| `practise` vs `practice` (UK verb vs noun) | Flag incorrect form |
| `-ise` vs `-ize` endings | Flag `organize`, `recognize` unless project allows -ize |
| `licence` (noun) vs `license` (verb) | Flag confusion |
| `programme` vs `program` | Flag `program` unless referring to software |

## Interaction with sub-skills

This sub-skill informs output grammar directly. For full publishing-house punctuation doctrine, see [`../publishing-doctrine/publishing-doctrine.md`](../publishing-doctrine/publishing-doctrine.md). For etiquette around feedback, editorial tone, and author relationships, see [`../writing-etiquette/writing-etiquette.md`](../writing-etiquette/writing-etiquette.md).
