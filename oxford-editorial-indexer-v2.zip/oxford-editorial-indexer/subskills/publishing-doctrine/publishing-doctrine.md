---
name: publishing-doctrine
parent_skill: oxford-editorial-indexer
version: 1.0.0
author: TABARC-Code
description: Full publishing-house doctrine for document structure, citation handling, footnotes, tables of contents, running heads, appendix control, and output presentation standards. Applied by the Oxford Editorial Indexer to all formal document outputs.
links:
  parent: ../../SKILL.md
  grammar_rules: ../grammar-rules/grammar-rules.md
  writing_etiquette: ../writing-etiquette/writing-etiquette.md
  editorial_doctrine: ../../references/editorial-doctrine.md
  cross_reference_discipline: ../../references/cross-reference-discipline.md
  indexing_schema: ../../references/indexing-schema.md
  related_external_skill_1: professional-technical-writing
  related_external_skill_2: kaizen
---

# Publishing Doctrine

> Sub-skill of the Oxford Editorial Indexer. Governs document structure, citation, footnote handling, appendix control, and output presentation across all formal outputs this skill produces.

Publishing discipline exists to make documents navigable, durable, and honest. It is not decoration. A document that cannot be trusted to mean what it says, or found again when needed, is not published: it is merely typed.

## Document structure doctrine

### Heading hierarchy

Maintain strict heading hierarchy. Do not skip levels. A level-3 heading (`###`) must live inside a level-2 heading (`##`), which must live inside a level-1 heading (`#`).

Every document this skill produces must begin with a single level-1 heading that declares the document's scope.

Do not use bold text as a substitute for headings. Bold is for emphasis within prose, not for structural navigation.

### Section naming

Section headings should be descriptive and consistent in grammatical form across a single document. Do not mix noun-phrase headings with imperative-verb headings in the same document.

Choose one form per document and apply it:
- Noun phrase: `Glossary`, `Project index`, `Conflict list`
- Imperative: `Build the glossary`, `Run the index`, `Resolve conflicts`

### Front matter

Formal output documents should carry:
- Title
- Document type (editorial control set, glossary, index, etc.)
- Project identifier
- Date of compilation
- Author or editor note
- Version or draft status if applicable

This information prevents documents from becoming orphaned artefacts three months later.

### Table of contents

For outputs longer than four sections, include a table of contents. This is not optional for any document intended to be opened again.

Use consistent anchor links if the output format supports them. Markdown headers create anchors automatically; use them.

## Citation handling

### Citation styles

This skill does not impose a citation style. It records which style the project uses and applies it consistently.

Acceptable styles include:
- MHRA (common for UK humanities)
- Chicago (author-date or notes-bibliography)
- APA (psychology, social sciences)
- Harvard (common in UK universities)
- House style (defined by the publisher or project)

Record the citation style in the editorial summary. If no style is stated, use a simplified note format and flag the absence.

### In-text citations

When quoting from the source document to support a glossary definition or editorial note, give the shortest unambiguous reference:

```
(Section 2.1)
(p. 14, para. 3)
(Rule 12, exception clause)
```

Do not paste long extracts into editorial tables. Quote the minimum needed to establish meaning or evidence. Paraphrase the rest.

### Source authority

The source document outranks inference. An editorial note that contradicts the source requires explicit justification and a flag for author review.

When a source is ambiguous, state the ambiguity. Do not resolve it by choosing the reading that produces a tidier register.

## Footnote and endnote handling

This skill does not produce footnotes in its core outputs. Register tables do not lend themselves to footnote apparatus.

However, when processing source documents that carry footnotes or endnotes:

1. Index significant notes with the same care as body text. A footnote containing a definition, exception, or caveat is editorial content.
2. Record footnote locations in the `first occurrence` or `reference` fields using `fn.` notation: `fn. 14, p. 7`.
3. If a footnote contradicts the body text, record a conflict entry.
4. Do not discard footnote content when building the glossary. Authors put things in footnotes because they want them there, not because they are unimportant.

## Table and figure references

When the source document contains numbered tables or figures, index them if they carry canonical information.

Use consistent reference notation:
```
Table 3.2
Figure 7
Appendix B, Table 1
```

Check that every in-text reference to a table or figure resolves correctly. Record broken table or figure references in the conflict list.

## Appendix handling

Appendices are not supplementary decoration. In rulebooks, manuals, and academic works, they often contain canonical definitions, exception rules, reference tables, and contact information.

Treat appendix content with equal editorial care. Index appendix headings. Record cross-references between body text and appendices. Flag appendices that are referenced but missing.

Document appendices in the project index under a consistent heading:
```
Appendix A: Glossary of terms
Appendix B: Designer notes
```

## Versioning and revision control

For documents produced across multiple sessions or revisions:

- Carry a version number in the front matter
- Note what changed in each version in an editorial change log
- Mark deprecated terms in the glossary with the version in which they were deprecated and what replaced them
- Never silently alter a `canonical` field without recording the change

This mirrors the kaizen principle: small, verified changes with a traceable history.

## Output quality standards

### Table legibility

Tables must be readable without the header row visible. A reader should be able to identify the type of row from its content.

Column widths are not a concern in Markdown; cell content is. Keep cell entries concise. Use the `Notes` column for explanation, not the main definition column.

### Prose density

Editorial summaries should be dense with information, not with words. One sentence per problem. One paragraph per section.

Avoid padding. `It should be noted that the following terms may require attention` contains four wasted words. `Three terms require attention` is correct.

### Completeness signals

Every output should end with one of:

1. `Output is complete. No author decisions outstanding.`
2. `Output is complete. [n] items require author decision. See conflict list.`
3. `Output is partial. [reason]. Sections [x], [y] could not be completed from available source.`

Do not end an output in ambiguous silence. A document that stops without a completion statement may have been interrupted or truncated. State the status.

## Interaction with sub-skills

For sentence-level grammar enforcement, see [`../grammar-rules/grammar-rules.md`](../grammar-rules/grammar-rules.md). For tone, author relationship, and feedback etiquette, see [`../writing-etiquette/writing-etiquette.md`](../writing-etiquette/writing-etiquette.md). For cross-reference verification standards, see [`../../references/cross-reference-discipline.md`](../../references/cross-reference-discipline.md).
