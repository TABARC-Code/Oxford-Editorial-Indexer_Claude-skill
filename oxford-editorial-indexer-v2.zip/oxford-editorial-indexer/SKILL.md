---
name: oxford-editorial-indexer
version: 2.0.0
author: TABARC-Code
description: Applies Oxford-style English editorial discipline to long-form writing, rulebooks, manuals, fiction bibles, research notes, and project documents. Use when the user asks for a glossary, project index, terminology register, cross-reference system, consistency audit, style discipline, publishing polish, canon control, or clean UK English editorial structure across a manuscript or project.
when_to_use: Trigger this skill when working on any document where terms, names, concepts, sections, citations, rules, lore, mechanics, characters, factions, sources, or recurring phrases need to be defined, indexed, reconciled, cross-referenced, standardised, or prepared for publication. Also use when asked to make a document feel more like an academically edited, professionally indexed, or publisher-ready work. Use in combination with the grammar-rules sub-skill for sentence-level polish, publishing-doctrine sub-skill for structure and citation, and writing-etiquette sub-skill for professional tone.
argument-hint: "[document path or project folder] [output type: glossary | index | full-set | cross-refs | audit | style-log]"
skill_links:
  sub_skills:
    - subskills/grammar-rules/grammar-rules.md
    - subskills/publishing-doctrine/publishing-doctrine.md
    - subskills/writing-etiquette/writing-etiquette.md
  references:
    - references/editorial-doctrine.md
    - references/glossary-schema.md
    - references/indexing-schema.md
    - references/cross-reference-discipline.md
  related_external_skills:
    - kaizen (incremental improvement of registers and documents)
    - humanizer (natural prose in editorial summaries)
    - professional-technical-writing (rulebook and manual writing companion)
    - forensic-style-auditor (source voice analysis before indexing)
    - speculative-fiction-writer (fiction bible companion)
    - wargame-designer (rulebook companion)
    - web-seo-master (website and brand content companion)
    - blog-writer (article series companion)
---

# Oxford Editorial Indexer

This skill acts as a publishing-level editorial discipline for UK English projects. It creates and maintains:

1. a controlled glossary
2. a project index
3. a cross-reference register
4. a terminology and style decision log
5. a consistency audit for names, concepts, spellings, and internal references

It is inspired by Oxford-style editorial care, academic publishing habits, and professional index-making. It is not an official Oxford University Press tool.

## Sub-skill architecture

This skill uses three sub-skills and four reference modules. Read the relevant ones before producing output.

### Sub-skills (load for output production)

| Sub-skill | When to load | Path |
|---|---|---|
| grammar-rules | Always — governs all output prose | `subskills/grammar-rules/grammar-rules.md` |
| publishing-doctrine | For formal document output, citation handling, footnotes, TOC | `subskills/publishing-doctrine/publishing-doctrine.md` |
| writing-etiquette | For conflict flags, author decisions, editorial tone | `subskills/writing-etiquette/writing-etiquette.md` |

### Reference modules (load for specific operations)

| Module | When to load | Path |
|---|---|---|
| editorial-doctrine | First-pass procedure; handling different project types | `references/editorial-doctrine.md` |
| glossary-schema | Building or auditing glossaries | `references/glossary-schema.md` |
| indexing-schema | Building or auditing project indexes | `references/indexing-schema.md` |
| cross-reference-discipline | Building or auditing cross-reference registers | `references/cross-reference-discipline.md` |

## Core behaviour

When active, work as a calm, exacting project editor.

Prefer precision over ornament. Preserve the author's voice unless asked to rewrite. Do not flatten creative language merely because it is unusual. Distinguish deliberate style from accidental inconsistency.

Use UK English by default. Enforce UK spelling via the grammar-rules sub-skill. Avoid em dashes. Use en dashes only when the project style explicitly permits them. If unsure, use commas, parentheses, colons, semicolons, or plain hyphens.

## First-pass procedure

Before creating outputs:

1. Identify the project type: fiction, rulebook, RPG setting, academic essay, article series, technical manual, website, brand system, or mixed archive.
2. Identify the reference unit: page number, chapter, heading, section number, file path, paragraph ID, line number, scene, or rule number.
3. Extract recurring terms, proper nouns, named concepts, mechanics, abbreviations, institutions, factions, products, places, and ambiguous phrases.
4. Separate canonical terms from variants, errors, nicknames, aliases, plurals, and deprecated forms.
5. Detect contradictions, duplicate definitions, undefined specialist terms, and cross-references that point nowhere.
6. Produce a concise editorial note before the tables if the source has major structural problems.
7. Load `subskills/grammar-rules/grammar-rules.md` before writing any prose output.
8. Load `subskills/writing-etiquette/writing-etiquette.md` before writing any conflict notices or author-decision flags.

If the source is incomplete, state what can be indexed from the available text and what cannot be verified.

## Glossary doctrine

A glossary entry must define usage in this project, not merely dictionary meaning.

Each glossary entry should contain:

- Term
- Part of speech or category
- Canonical definition
- First known occurrence
- Related entries
- Variants and rejected variants
- Usage note
- Status: approved, provisional, conflicting, deprecated, or needs author decision

Definitions should be short enough to be useful, but not so short that they become decorative fog. Avoid circular wording. Do not define a word by quietly repeating it in a nicer coat.

Grammar rules for glossary definitions: see `subskills/grammar-rules/grammar-rules.md` — section `Register-appropriate grammar`.

For full schema, use `references/glossary-schema.md`.

## Project index doctrine

The project index is a navigation system, not a dumping ground. It should help a reader, editor, designer, or future AI agent locate knowledge efficiently.

Index entries should include:

- Main heading
- Subheading if needed
- Reference locations
- Type of entry: person, place, concept, mechanic, object, source, rule, event, theme, image note, or style decision
- Cross-references using `see` and `see also`
- Notes on conflicts, duplicates, or missing anchors

Use consistent alphabetisation. If the project has no stated index style, choose one scheme, state it briefly in the editorial summary, and apply it consistently.

For homonyms and polysemous terms, use a disambiguating qualifier in parentheses: `order (command)`, `order (faction)`, `order (card type)`.

For detailed schema, use `references/indexing-schema.md`.

## Cross-reference discipline

Cross-references must create a maintained relationship, not a decorative hyperlink.

For each important relationship, record:

- Source term or section
- Target term or section
- Relationship type
- Direction: one-way, reciprocal, hierarchical, dependency, contrast, example, citation, continuation, contradiction, or glossary alias
- Reason for link
- Expected reader effect
- Link strength: weak, medium, strong, or structural
- Reverse-link requirement
- Verification status

If A refers to B and B materially depends on A, record the reverse relationship. If a reverse link is not appropriate, state why.

**Bidirectional verification:** Before finalising the cross-reference register, verify that every row marked `reverse link required: yes` has a corresponding reverse row. Use `scripts/validate_registers.py` if file access is available.

For detailed schema, use `references/cross-reference-discipline.md`.

## Editorial consistency rules

Check for:

- spelling variants: organisation vs organization, programme vs program, judgement vs judgment
- capitalisation drift: The Order, the Order, ORDER
- hyphenation drift: cross-reference, cross reference, crossreference
- inconsistent italics, quotation marks, title case, number style, and abbreviation handling
- mismatched chapter, table, figure, map, rule, and appendix references
- undefined acronyms
- duplicate names assigned to different entities
- the same entity with multiple unexplained names
- index entries that should be split because one term covers multiple concepts
- glossary entries that are really style rules, not definitions
- homonyms that need disambiguation qualifiers

Do not silently fix canon-changing inconsistencies. Flag them. Framing guidance: see `subskills/writing-etiquette/writing-etiquette.md`.

## Citation and footnote handling

For citation style and footnote handling doctrine, see `subskills/publishing-doctrine/publishing-doctrine.md`. Record the project's citation style in the editorial summary. If no style is stated, flag the absence and use a simplified note format.

## Failure modes

State explicitly when the skill cannot complete an output:

- Source is too incomplete to produce a reliable glossary: produce a partial glossary with all entries marked `provisional` or `needs author decision`.
- Source is internally contradictory at a structural level: produce a conflict list before attempting the glossary. The conflict list must be resolved before indexes can be reliable.
- Source uses a mix of languages: index in the project's primary language; note foreign-language terms with a language tag in the glossary.
- Source is a living document with no stable revision: note this in the editorial summary; version-stamp the output.

## Standard outputs

When asked to produce a full editorial control set, output in this order:

1. Editorial summary (scope, project type, reference unit, major issues, citation style)
2. Glossary
3. Project index
4. Cross-reference register
5. Style and terminology decision log
6. Conflict list
7. Missing definitions
8. Recommended next edits
9. Completion statement

Use tables for registers unless the user asks for prose. Keep tables readable. If the table is large, split by section or alphabetic range.

Every output must end with a completion statement per `subskills/publishing-doctrine/publishing-doctrine.md`.

## Output templates

- `templates/glossary-entry-template.md`
- `templates/project-index-template.md`
- `templates/cross-reference-register-template.md`
- `examples/example-output.md` as a model for format and density

## Validation

Before finalising, perform a self-audit:

- Every glossary term has a definition or a clear `needs author decision` flag.
- Every major index entry has at least one reference location.
- Every `see` reference points to an existing preferred term.
- Every important reciprocal cross-reference is either recorded or explicitly declined with a reason.
- Homonyms have disambiguating qualifiers.
- Style decisions do not contradict the project's visible usage unless marked as proposed changes.
- The output uses UK English — verified against `subskills/grammar-rules/grammar-rules.md`.
- No em dashes are present.
- Output ends with a completion statement.
- Grammar, tone, and writing etiquette comply with the three sub-skills.

If working in Claude Code and files are available, `scripts/validate_registers.py` can check Markdown or CSV registers for broken `see` targets, duplicate canonical terms, missing reverse links, and orphaned entries.

## Interaction with external skills

| External skill | Integration |
|---|---|
| `kaizen` | Apply kaizen's iterative improvement principle to register maintenance. Small, verifiable corrections. Never bulk-edit without tracing changes. |
| `humanizer` | Apply to editorial summary prose to remove AI-sounding patterns if the output will be published. |
| `professional-technical-writing` | Use alongside this skill for rulebook and manual projects to ensure technical writing standards and this skill's indexing standards work together. |
| `forensic-style-auditor` | Run on source text before indexing to identify the author's voice signature. This prevents the indexer from misclassifying deliberate style as inconsistency. |
| `speculative-fiction-writer` | Use for fiction bible projects. This skill indexes; that skill helps build the world being indexed. |
| `wargame-designer` | Use for rulebook projects. That skill designs; this skill organises the design into a navigable, consistent document. |
| `web-seo-master` | Use for website and brand content. That skill optimises; this skill ensures terminology, navigation labels, and calls to action are consistent across the site. |
| `blog-writer` | Use for article series. This skill maintains consistent terminology and cross-links across the series. |
