---
author: TABARC-Code
links:
  parent: ../SKILL.md
  editorial_doctrine: editorial-doctrine.md
  cross_reference_discipline: cross-reference-discipline.md
  indexing_schema: indexing-schema.md
  grammar_rules: ../subskills/grammar-rules/grammar-rules.md
  writing_etiquette: ../subskills/writing-etiquette/writing-etiquette.md
---

# Glossary Schema

> Reference module of the Oxford Editorial Indexer. See also: `../subskills/grammar-rules/grammar-rules.md` for definition grammar; `../subskills/writing-etiquette/writing-etiquette.md` for usage note framing.

## Purpose

A glossary defines project-specific meaning. It should make the work easier to read, edit, translate, expand, and maintain.

A glossary is not a dictionary extract. It is a compact model of the project's vocabulary.

## Entry fields

| Field | Required | Use |
|---|---:|---|
| Term | Yes | Canonical spelling and capitalisation. |
| Category | Yes | See category types below. |
| Definition | Yes | The meaning inside this project. |
| First occurrence | Preferred | First known file, section, page, heading, scene, rule, or paragraph. |
| Related entries | Preferred | Terms that expand, contrast, depend on, or clarify this entry. |
| Variants | Optional | Accepted aliases, abbreviations, nicknames, older spellings, or plural forms. |
| Rejected variants | Optional | Forms that must not be used. |
| Usage note | Optional | Guidance on tone, register, capitalisation, context, or grammar category. |
| Status | Yes | Approved, provisional, conflicting, deprecated, or needs author decision. |
| Evidence | Preferred | Source quote or reference location supporting the definition. |

## Category types

| Category | Use |
|---|---|
| Concept | An abstract idea central to the project. |
| Character | A named person, being, or entity. |
| Faction | An organisation, group, or affiliation. |
| Place | A named location. |
| Object | A physical item, artefact, or component. |
| Mechanic | A gameplay or system rule. |
| Rule | A formal instruction or constraint. |
| Phase | A distinct period or sequence step in a game or process. |
| Keyword | A formal game or system term with a defined mechanical meaning. |
| Acronym | An abbreviation requiring expansion on first use. |
| Style term | A term governing format, not content. |
| Source | A cited document, book, or reference. |
| Image note | A term tied to visual content. |
| Verb | An action term with a defined operational meaning in the project. |
| Other | Terms that do not fit the above; note the reason. |

## Definition rules

1. Define the term in the project's own conceptual frame.
2. Use plain English first, specialist vocabulary second.
3. Avoid circular definitions.
4. Avoid vague intensifiers: `very`, `extremely`, `highly`, `deeply` — unless they are part of the source voice.
5. State ambiguity instead of hiding it.
6. Preserve fictional, technical, ritual, or brand terms where they are intentional.
7. Mark invented terms clearly when their meaning is inferred.
8. Write definitions in present tense, declarative form. See `../subskills/grammar-rules/grammar-rules.md` — section `Register-appropriate grammar`.

## Homonym and polysemy handling

When a single term has two or more distinct meanings within the same project:

1. Create a separate entry for each meaning.
2. Append a disambiguating qualifier in parentheses to the `Term` field: `order (command)`, `order (faction)`, `order (card type)`.
3. Add a `see also` cross-reference between all entries sharing the term.
4. Note in the editorial summary that the term is polysemous and list the entries.

Do not attempt to merge the meanings into one definition. A merged definition for a polysemous term is a circular definition wearing a coat.

## Compound terms and portmanteau neologisms

For compound terms:

1. Record the full compound form as the canonical term.
2. Record the abbreviated or partial form as a variant.
3. Note hyphenation style in the usage note if it varies across the source.

For portmanteau neologisms and invented compound words:

1. Accept the author's spelling as canonical.
2. Note the evident constituent terms in the definition or usage note.
3. Mark status as `provisional` if the author has not given an explicit definition.

## Sorting

Use alphabetical order by canonical heading. Ignore initial articles (`the`, `a`, `an`) unless the article is part of a formal title.

Sort letter-by-letter (ignoring spaces and hyphens) unless the project has a stated word-by-word convention. State the chosen method in the editorial summary and apply it without variation.

Numbers sort before letters. Symbols sort before numbers. Note the method.

## Definition quality scale

| Status | Meaning |
|---|---|
| Approved | Source usage is clear and internally consistent. |
| Provisional | Meaning is likely, but the source does not fully define it. |
| Conflicting | Two or more source uses disagree. |
| Deprecated | Older term replaced by a preferred term. |
| Needs author decision | No responsible definition can be made from current evidence. |

## Preferred glossary format

```markdown
| Term | Category | Definition | First occurrence | Related entries | Variants | Status | Notes |
|---|---|---|---|---|---|---|---|
| Example term | Concept | Project-specific definition. | Ch. 2, section 1 | Related term | Old form | Approved | Usage note. |
```
