---
author: TABARC-Code
links:
  parent: ../SKILL.md
  editorial_doctrine: editorial-doctrine.md
  glossary_schema: glossary-schema.md
  indexing_schema: indexing-schema.md
  grammar_rules: ../subskills/grammar-rules/grammar-rules.md
  publishing_doctrine: ../subskills/publishing-doctrine/publishing-doctrine.md
  writing_etiquette: ../subskills/writing-etiquette/writing-etiquette.md
  validator: ../scripts/validate_registers.py
---

# Cross-reference Discipline

> Reference module of the Oxford Editorial Indexer. See also: `../subskills/grammar-rules/grammar-rules.md` for prose standards in reason and reader-effect fields; `../subskills/writing-etiquette/writing-etiquette.md` for conflict framing.

## Purpose

A cross-reference is a maintained editorial relationship, not merely a link.

The aim is to stop long projects becoming fog banks of duplicated concepts, half-renamed factions, forgotten rules, orphaned appendices, and lore that contradicts itself three chapters later.

## Bidirectional verification procedure

Before finalising any cross-reference register:

1. For every row where `reverse link required` is `yes`, confirm a corresponding reverse row exists.
2. If no reverse row exists, create it or mark it `reverse link present: no — needs update`.
3. Run `scripts/validate_registers.py` if file access is available.
4. Record the verification date and status in the editorial summary.

A cross-reference register that has not been verified for bidirectional completeness is not a register. It is a list of intentions.

## Orphan detection

An orphaned cross-reference is a `see` or `see also` target that does not exist as a main heading or canonical term anywhere in the register or index.

Before finalising:
1. Extract all `see` and `see also` values from the index.
2. Confirm each value exists as a main heading in the same index.
3. Extract all `Target` values from the cross-reference register.
4. Confirm each target exists as a canonical term in the glossary or a main heading in the index.
5. Report all orphans in the conflict list.

Use `scripts/validate_registers.py` for automated orphan detection.

## Circular reference detection

A circular reference occurs when A cross-references B and B cross-references A as the authoritative source for each other — with no independent definition for either.

To detect:
1. For any reciprocal pair (A → B, B → A), verify that at least one of the pair has an independent `approved` or `provisional` glossary definition with a source citation.
2. If both entries rely solely on each other, flag as `circular reference — independent definition required`.

## Relationship types

| Type | Use |
|---|---|
| Alias | Different names for the same thing. Always bidirectional. |
| Preferred term | Redirects variant wording to canonical wording. |
| Parent-child | A concept contains another concept. Child links to parent; parent may link to children. |
| Dependency | One section, rule, or idea requires another. Check bidirectional need. |
| Example | One item illustrates another. Usually one-way. |
| Contrast | One item clarifies another by opposition. Consider reciprocal link. |
| Continuation | One section continues material from another. Usually one-way. |
| Citation | One source supports or challenges another. Consider reciprocal for contested claims. |
| Contradiction | Two entries conflict and require resolution. Always bidirectional. |
| Design link | A layout, image, rule, or style note depends on another element. |
| Glossary link | A defined term should be connected to another defined term. |

## Register fields

| Field | Required | Use |
|---|---:|---|
| Source | Yes | Term, section, rule, heading, file, or entry creating the reference. |
| Target | Yes | Term, section, rule, heading, file, or entry being referenced. |
| Relationship type | Yes | Alias, dependency, contrast, parent-child, contradiction, and so on. |
| Direction | Yes | One-way, reciprocal, hierarchical, reverse-only, or pending. |
| Reason | Yes | One complete sentence stating why the connection matters. See grammar rules. |
| Reader effect | Preferred | What the link helps the reader understand or find. One sentence. |
| Link strength | Yes | Weak, medium, strong, or structural. |
| Reverse link required | Yes | Yes, no, or conditional. |
| Reverse link present | Preferred | Yes, no, not checked, or not applicable. |
| Status | Yes | Verified, inferred, broken, conflicting, or needs author decision. |

All `Reason` and `Reader effect` entries must comply with grammar standards in `../subskills/grammar-rules/grammar-rules.md`.

## Reverse-link rule

If A materially depends on B, check whether B should acknowledge A.

Reverse links are normally required for:

- glossary aliases
- rule dependencies
- faction relationships
- character relationships
- source and claim relationships
- recurring mechanics
- chapter-to-appendix references
- image notes tied to text
- lore dependencies
- technical dependencies

Reverse links are not always required for:

- simple examples
- passing references
- one-off citations
- linear narrative continuation
- parent entries that would become overloaded

When declining a reverse link, state the reason in the register row. Do not leave the `reverse link required` field blank.

## Link strength

| Strength | Meaning |
|---|---|
| Weak | Helpful but optional. |
| Medium | Useful for navigation or understanding. |
| Strong | Important for consistency or reader comprehension. |
| Structural | The project breaks, contradicts itself, or becomes misleading without it. |

## Cross-references to external documents

When a source document references external material not available in the current project:

1. Record the external reference in the register with status `inferred` or `unverified`.
2. Note the reference location.
3. Do not create a glossary entry for the external term unless the project has adopted it.
4. If the external reference is structural (the project's meaning depends on it), flag for author confirmation.

## Cross-references in sessions without file access

When operating without file access — that is, when the entire source has been provided in the conversation — apply all procedures as above, but note in the editorial summary: `Cross-reference verification performed against conversation context only. File-based validation not available.`

## Broken reference handling

For broken links, output:

1. Broken source location
2. Missing target
3. Likely intended target, if inferable
4. Confidence level: high, medium, low
5. Recommended fix
6. Whether author decision is required

Framing for conflict notices must comply with `../subskills/writing-etiquette/writing-etiquette.md`.
