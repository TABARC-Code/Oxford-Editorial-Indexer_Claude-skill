---
author: TABARC-Code
links:
  parent: ../SKILL.md
  editorial_doctrine: editorial-doctrine.md
  cross_reference_discipline: cross-reference-discipline.md
  glossary_schema: glossary-schema.md
  grammar_rules: ../subskills/grammar-rules/grammar-rules.md
  publishing_doctrine: ../subskills/publishing-doctrine/publishing-doctrine.md
---

# Project Index Schema

> Reference module of the Oxford Editorial Indexer. See also: `../subskills/publishing-doctrine/publishing-doctrine.md` for TOC and appendix handling; `../subskills/grammar-rules/grammar-rules.md` for note prose standards.

## Purpose

A project index is a retrieval tool. It should help a reader or editor find significant material without rereading the whole work.

Index the things a human would look for later:

- names, places, and factions
- rules, mechanics, and phases
- themes and motifs
- technical terms and artefacts
- products and recurring examples
- tables and figures
- major claims and source documents
- style decisions and editorial notes

Do not index every passing noun.

## Entry fields

| Field | Required | Use |
|---|---:|---|
| Main heading | Yes | Canonical index heading. |
| Subheading | Optional | Specific aspect under the heading. |
| Sub-subheading | Optional | A further level, used sparingly; note when it is applied. |
| Reference | Yes | Page, section, file path, rule number, paragraph, heading, or scene. |
| Entry type | Preferred | Person, place, concept, mechanic, object, event, source, theme, image note, or style decision. |
| See | Optional | Redirect from a non-preferred term to the preferred term. |
| See also | Optional | Related term, not a substitute. |
| Note | Optional | Editorial clarification, conflict, or warning. Complete sentences required — see grammar rules. |

## Sub-subheadings

Use sub-subheadings when a main heading contains multiple distinct aspects that would create an unreadable flat list. Three or more substantive subheadings under a single heading may warrant a sub-subheading if they differ along a clear second dimension.

State in the editorial summary when sub-subheadings are applied, and the dimension they represent.

## Proper nouns vs common nouns

Proper nouns index under their canonical capitalised form: `Arcanum, the`, `Order of Silence`, `Phase Three`.

Common nouns that have been given formal status in the project (defined in the glossary, used as game terms) index under their lowercase canonical form unless the project has explicitly capitalised them.

When a proper noun and a common noun share the same string, create two separate entries with disambiguating qualifiers. See `glossary-schema.md` — section `Homonym and polysemy handling`.

## Alphabetisation

State the alphabetisation method in the editorial summary and apply it without variation.

**Letter-by-letter** (default for this skill): ignore spaces, hyphens, and apostrophes when sorting. `Cross-reference` sorts as `crossreference`.

**Word-by-word** (use only if the project requires it): sort by first word, then second. `Cross reference` sorts before `Crossbow`.

Numbers sort before letters. Symbols sort before numbers. For runs of numbers in headings, sort numerically, not lexicographically: `Rule 9` before `Rule 10`, not after.

## Indexing judgement

Include an entry when:

1. the term is central to the work
2. readers are likely to seek it
3. it carries a definition, rule, relationship, event, or decision
4. it appears in several places with meaningful development
5. it anchors a cross-reference cluster
6. it is a source of possible confusion
7. it is a homonym requiring disambiguation

Exclude an entry when:

1. it is merely decorative
2. it appears once without conceptual weight
3. it duplicates a better heading
4. it belongs in the glossary only
5. it is a line edit rather than project knowledge

## Cross-reference language

Use `see` for redirection:

```text
AI systems, see artificial intelligence systems
```

Use `see also` for relationship:

```text
artificial intelligence systems, see also automation, agency, machine ethics
```

A `see` target must exist as a main heading. A `see also` target should exist unless the index is intentionally pointing to a future missing entry, which must be noted.

## Note prose standards

All `Note` fields must contain complete sentences. Fragment notes are not acceptable. Apply grammar standards from `../subskills/grammar-rules/grammar-rules.md`.

Model note: `This term appears in both the rulebook and the lore appendix with subtly different meanings. The index entry covers both; see conflict list for details.`

Not: `See conflict list — two meanings.`

## Orphan entry handling

An orphan index entry has no valid reference location. This usually occurs when:

- the source section was deleted or renumbered after the index was built
- the reference unit changed between drafts
- the entry was created from a planned section that was never written

Record orphan entries in the conflict list. Do not silently delete them. The author may need to know.
