#!/usr/bin/env python3
"""
validate_registers.py
Lightweight validator for glossary, index, and cross-reference registers.
Author: TABARC-Code
Part of: oxford-editorial-indexer skill

This script checks Markdown tables or simple CSV exports for common editorial control faults:

  - duplicate canonical terms
  - `see` targets that do not exist as main headings
  - cross-reference rows requiring reverse links where no reverse row is present
  - missing or unusual status values
  - empty definition or reason fields
  - orphaned cross-reference targets (targets not present as glossary terms or index headings)
  - circular cross-references (A -> B and B -> A with no independent definition for either)
  - summary statistics per register

It is deliberately conservative. It does not pretend to know your canon.
That would be how the paperwork starts lying.

Usage:
  python validate_registers.py glossary.md index.md crossrefs.md
  python validate_registers.py registers/*.csv

Exit codes:
  0  No faults found
  1  Faults found
  2  File not found or unreadable
"""

from __future__ import annotations

import argparse
import csv
import re
import sys
from pathlib import Path
from typing import Dict, Iterable, List, Set, Tuple


VALID_STATUSES: Set[str] = {
    "approved",
    "provisional",
    "conflicting",
    "deprecated",
    "needs author decision",
    "verified",
    "inferred",
    "broken",
    "not checked",
    "not applicable",
}

DEFINITION_FIELDS = ["definition", "reason", "canonical definition"]
REVERSE_REQUIRED_TRUTHY = {"yes", "true", "required", "y"}


def normalise(value: str) -> str:
    return re.sub(r"\s+", " ", value.strip().lower())


def parse_markdown_table(text: str) -> List[Dict[str, str]]:
    rows: List[Dict[str, str]] = []
    lines = [line.strip() for line in text.splitlines() if line.strip().startswith("|")]
    if len(lines) < 2:
        return rows

    i = 0
    while i < len(lines) - 1:
        header_line = lines[i]
        divider_line = lines[i + 1]
        if not re.match(r"^\|?\s*:?-{3,}:?", divider_line.replace("|", "| ")):
            i += 1
            continue

        headers = [cell.strip() for cell in header_line.strip("|").split("|")]
        i += 2
        while i < len(lines):
            line = lines[i]
            if re.match(r"^\|?\s*:?-{3,}:?", line.replace("|", "| ")):
                break
            cells = [cell.strip() for cell in line.strip("|").split("|")]
            if len(cells) == len(headers):
                rows.append(dict(zip(headers, cells)))
            i += 1
    return rows


def parse_csv(path: Path) -> List[Dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def read_rows(path: Path) -> List[Dict[str, str]]:
    if path.suffix.lower() == ".csv":
        return parse_csv(path)
    return parse_markdown_table(path.read_text(encoding="utf-8"))


def first_present(row: Dict[str, str], names: Iterable[str]) -> str:
    lookup = {normalise(key): value for key, value in row.items()}
    for name in names:
        value = lookup.get(normalise(name), "")
        if value:
            return value
    return ""


def collect_canonical_terms(rows: List[Dict[str, str]]) -> Set[str]:
    """Return all canonical terms and main headings from a set of rows."""
    terms: Set[str] = set()
    for row in rows:
        term = first_present(row, ["Term", "Main heading", "Source"])
        if term:
            terms.add(normalise(term))
    return terms


def validate(rows: List[Dict[str, str]], all_known_terms: Set[str]) -> Tuple[List[str], Dict[str, int]]:
    warnings: List[str] = []
    stats: Dict[str, int] = {
        "rows": len(rows),
        "duplicates": 0,
        "orphaned_see_targets": 0,
        "missing_reverse_links": 0,
        "empty_definitions": 0,
        "unusual_statuses": 0,
        "orphaned_xref_targets": 0,
        "circular_references": 0,
    }

    canonical_terms: Dict[str, int] = {}
    main_headings: Set[str] = set()
    crossrefs: Set[Tuple[str, str]] = set()
    terms_with_definitions: Set[str] = set()

    # First pass: collect structure
    for idx, row in enumerate(rows, start=1):
        term = first_present(row, ["Term", "Main heading", "Source"])
        heading = first_present(row, ["Main heading", "Term"])
        source = first_present(row, ["Source"])
        target = first_present(row, ["Target"])
        status = first_present(row, ["Status"])
        definition = first_present(row, DEFINITION_FIELDS)

        if term:
            key = normalise(term)
            canonical_terms[key] = canonical_terms.get(key, 0) + 1

        if heading:
            main_headings.add(normalise(heading))

        if source and target:
            crossrefs.add((normalise(source), normalise(target)))

        if definition:
            term_key = normalise(term or source or "")
            if term_key:
                terms_with_definitions.add(term_key)

        if status and normalise(status) not in VALID_STATUSES:
            warnings.append(f"Row {idx}: unusual status value `{status}`.")
            stats["unusual_statuses"] += 1

        if not definition:
            # Only warn if the row has a term (not every row type needs a definition)
            if term or source:
                warnings.append(
                    f"Row {idx}: definition or reason field is empty for `{term or source}`."
                )
                stats["empty_definitions"] += 1

    # Duplicate canonical terms
    for term, count in sorted(canonical_terms.items()):
        if count > 1:
            warnings.append(
                f"Duplicate canonical heading or term: `{term}` appears {count} times."
            )
            stats["duplicates"] += 1

    # Second pass: verify see-targets, reverse links, orphaned xref targets
    combined_headings = main_headings | all_known_terms

    for idx, row in enumerate(rows, start=1):
        see_target = first_present(row, ["See"])
        if see_target:
            norm_target = normalise(see_target)
            if norm_target not in combined_headings:
                warnings.append(
                    f"Row {idx}: `see` target `{see_target}` is not present as a "
                    f"main heading or canonical term."
                )
                stats["orphaned_see_targets"] += 1

        source = first_present(row, ["Source"])
        target = first_present(row, ["Target"])
        reverse_required = normalise(first_present(row, ["Reverse link required"]))

        if source and target:
            # Orphaned xref target check
            if normalise(target) not in combined_headings:
                warnings.append(
                    f"Row {idx}: cross-reference target `{target}` does not exist "
                    f"as a canonical term or main heading."
                )
                stats["orphaned_xref_targets"] += 1

            # Reverse link check
            if reverse_required in REVERSE_REQUIRED_TRUTHY:
                reverse_pair = (normalise(target), normalise(source))
                if reverse_pair not in crossrefs:
                    warnings.append(
                        f"Row {idx}: reverse link required for `{source}` → `{target}`, "
                        f"but no reverse row found."
                    )
                    stats["missing_reverse_links"] += 1

    # Circular reference detection
    for (src, tgt) in crossrefs:
        if (tgt, src) in crossrefs:
            # Reciprocal pair found — check whether at least one has an independent definition
            if src not in terms_with_definitions and tgt not in terms_with_definitions:
                warnings.append(
                    f"Possible circular reference: `{src}` and `{tgt}` reference each other "
                    f"with no independent definition found for either. "
                    f"At least one requires a standalone definition."
                )
                stats["circular_references"] += 1

    return warnings, stats


def print_summary(path: Path, warnings: List[str], stats: Dict[str, int]) -> None:
    print(f"\n{'='*60}")
    print(f"File: {path}")
    print(f"Rows parsed: {stats['rows']}")
    print(f"  Duplicates:            {stats['duplicates']}")
    print(f"  Empty definitions:     {stats['empty_definitions']}")
    print(f"  Orphaned see-targets:  {stats['orphaned_see_targets']}")
    print(f"  Missing reverse links: {stats['missing_reverse_links']}")
    print(f"  Orphaned xref targets: {stats['orphaned_xref_targets']}")
    print(f"  Circular references:   {stats['circular_references']}")
    print(f"  Unusual statuses:      {stats['unusual_statuses']}")
    if warnings:
        print(f"\nFaults ({len(warnings)}):")
        for warning in warnings:
            print(f"  - {warning}")
    else:
        print("\nNo register faults found.")
    print(f"{'='*60}")


def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Validate editorial registers for the oxford-editorial-indexer skill. "
            "Checks glossaries, project indexes, and cross-reference registers "
            "in Markdown or CSV format."
        )
    )
    parser.add_argument("paths", nargs="+", help="Markdown or CSV files to validate")
    args = parser.parse_args()

    # Collect all canonical terms across all files first (for cross-file orphan detection)
    all_rows: Dict[str, List[Dict[str, str]]] = {}
    exit_code = 0

    for raw_path in args.paths:
        path = Path(raw_path)
        if not path.exists():
            print(f"Missing file: {path}", file=sys.stderr)
            exit_code = 2
            continue
        rows = read_rows(path)
        all_rows[str(path)] = rows

    all_known_terms: Set[str] = set()
    for rows in all_rows.values():
        all_known_terms |= collect_canonical_terms(rows)

    for raw_path, rows in all_rows.items():
        path = Path(raw_path)
        if not rows:
            print(f"\n{path}: no parseable table rows found")
            continue

        warnings, stats = validate(rows, all_known_terms)
        print_summary(path, warnings, stats)

        if warnings:
            exit_code = max(exit_code, 1)

    # Global summary
    total_files = len(all_rows)
    total_faults = sum(
        len(validate(rows, all_known_terms)[0]) for rows in all_rows.values()
    )
    print(f"\nValidation complete. {total_files} file(s). {total_faults} total fault(s).")

    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
