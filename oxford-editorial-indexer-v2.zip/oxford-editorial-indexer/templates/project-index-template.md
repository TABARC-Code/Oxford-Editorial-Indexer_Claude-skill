---
author: TABARC-Code
links:
  parent: ../SKILL.md
  schema: ../references/indexing-schema.md
  grammar: ../subskills/grammar-rules/grammar-rules.md
  publishing: ../subskills/publishing-doctrine/publishing-doctrine.md
---

# Project Index Template

> For full field definitions and alphabetisation rules, see `references/indexing-schema.md`.
> For note prose standards (complete sentences required), see `subskills/grammar-rules/grammar-rules.md`.
> For disambiguation qualifiers for homonyms, see `references/glossary-schema.md`.

## Table form

```markdown
## Project Index

| Main heading | Subheading | Reference | Entry type | See | See also | Note |
|---|---|---|---|---|---|---|
|  |  | §, p., ch., fn., fig. |  | Preferred term only |  | Complete sentences. |
```

## Alphabetic section format

```markdown
### A

| Main heading | Subheading | Reference | Entry type | Cross-reference | Note |
|---|---|---|---|---|---|
|  |  |  |  |  |  |
```

## Entry type values

`person` · `place` · `concept` · `mechanic` · `object` · `event` · `source` · `theme` · `image note` · `style decision` · `rule` · `faction` · `phase`

## Cross-reference language

- `see [preferred term]` — redirection only; target must exist as a main heading
- `see also [related term]` — relationship; target should exist

## Alphabetisation note

State the method in the editorial summary. This skill defaults to letter-by-letter (spaces and hyphens ignored). Numbers before letters; symbols before numbers.
