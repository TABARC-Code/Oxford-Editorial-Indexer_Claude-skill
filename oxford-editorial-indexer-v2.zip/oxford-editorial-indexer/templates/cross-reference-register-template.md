---
author: TABARC-Code
links:
  parent: ../SKILL.md
  schema: ../references/cross-reference-discipline.md
  grammar: ../subskills/grammar-rules/grammar-rules.md
  validator: ../scripts/validate_registers.py
---

# Cross-reference Register Template

> For full field definitions, relationship types, and reverse-link rules, see `references/cross-reference-discipline.md`.
> For reason and reader-effect prose (complete sentences required), see `subskills/grammar-rules/grammar-rules.md`.
> For bidirectional verification procedure, see `references/cross-reference-discipline.md` — section `Bidirectional verification procedure`.
> Run `scripts/validate_registers.py` to check for missing reverse links, orphaned targets, and circular references.

## Main register

```markdown
## Cross-reference Register

| Source | Target | Relationship type | Direction | Reason | Reader effect | Link strength | Reverse link required | Reverse link present | Status |
|---|---|---|---|---|---|---|---|---|---|
|  |  | alias / preferred-term / parent-child / dependency / example / contrast / continuation / citation / contradiction / design-link / glossary-link |  | One complete sentence. |  | weak / medium / strong / structural | yes / no / conditional | yes / no / not checked / not applicable | verified / inferred / broken / conflicting / needs author decision |
```

## Broken or unverified references

```markdown
## Broken or Unverified References

| Source | Missing target | Likely intended target | Confidence | Recommended fix | Author decision required |
|---|---|---|---|---|---|
|  |  |  | high / medium / low |  | yes / no |
```

## Bidirectional verification checklist

Before finalising, confirm:

- [ ] All rows with `reverse link required: yes` have a corresponding reverse row.
- [ ] All `Target` values exist as canonical terms or main headings.
- [ ] No circular reference pairs lack an independent definition.
- [ ] `scripts/validate_registers.py` run and output reviewed.
