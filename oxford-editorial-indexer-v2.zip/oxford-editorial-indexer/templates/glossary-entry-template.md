---
author: TABARC-Code
links:
  parent: ../SKILL.md
  schema: ../references/glossary-schema.md
  grammar: ../subskills/grammar-rules/grammar-rules.md
---

# Glossary Template

> For full field definitions and category types, see `references/glossary-schema.md`.
> For definition grammar (present tense, declarative, no circular wording), see `subskills/grammar-rules/grammar-rules.md`.
> For homonym handling (disambiguating qualifiers), see `references/glossary-schema.md` — section `Homonym and polysemy handling`.

## Table form (preferred for registers)

```markdown
| Term | Category | Definition | First occurrence | Related entries | Variants | Rejected variants | Status | Notes |
|---|---|---|---|---|---|---|---|---|
|  |  | Present tense, declarative. No circular wording. |  | `see also` targets |  |  | approved / provisional / conflicting / deprecated / needs author decision |  |
```

## Single-entry expanded form (preferred for detailed editorial review)

```markdown
### Term

- **Category:** concept / character / faction / place / object / mechanic / rule / phase / keyword / acronym / style term / source / image note / verb / other
- **Definition:** [Present tense. Declarative. Project-specific meaning. No circular wording.]
- **First occurrence:** [file, section, page, heading, scene, or rule]
- **Related entries:** [comma-separated list of canonical terms]
- **Variants:** [accepted aliases, abbreviations, older spellings, plural forms]
- **Rejected variants:** [forms that must not be used]
- **Usage note:** [capitalisation, tone, register, or grammar category guidance]
- **Status:** approved / provisional / conflicting / deprecated / needs author decision
- **Evidence:** [source quote or reference location]
```

## Homonym entry form (use when one term has multiple distinct meanings)

```markdown
### Term (qualifier A)

- **Category:**
- **Definition:** [Meaning A — project-specific.]
- **First occurrence:**
- **See also:** Term (qualifier B)
- **Status:**

### Term (qualifier B)

- **Category:**
- **Definition:** [Meaning B — project-specific.]
- **First occurrence:**
- **See also:** Term (qualifier A)
- **Status:**
```

## Status values

| Status | Use |
|---|---|
| Approved | Source usage is clear and internally consistent. |
| Provisional | Meaning is likely, but the source does not fully define it. |
| Conflicting | Two or more source uses disagree. See conflict list. |
| Deprecated | Older term replaced by a preferred term. Record the replacement. |
| Needs author decision | No responsible definition can be made from current evidence. State exactly what decision is required. |
